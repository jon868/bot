#!/usr/bin/env node
// Instalador sin SSH: se ejecuta dentro del contenedor de OpenClaw (consola de Easypanel).
//
//   node instalar.mjs --numero +34636487463 --email tu@correo.com --telefono "600 00 00 00"
//
// - Copia plantilla-datos/ a ~/.openclaw/asistente-jon (si ya existe, NO la sobrescribe).
// - Rellena propietario.numeros / email / telefono en reglas.json.
// - Instala workspace/AGENTS.md (con copia .bak) y aparta BOOTSTRAP.md.
// - Muestra los comandos de OpenClaw que faltan.
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { parseArgs } from 'node:util';
import { fileURLToPath } from 'node:url';

const aqui = path.dirname(fileURLToPath(import.meta.url));
const { values: a } = parseArgs({
  options: {
    numero: { type: 'string' },
    email: { type: 'string' },
    telefono: { type: 'string' },
    base: { type: 'string', default: path.join(os.homedir(), '.openclaw') },
  },
});

const base = a.base;
const dataDir = path.join(base, 'asistente-jon');
const workspace = path.join(base, 'workspace');
const ok = (m) => console.log('✔ ' + m);

if (!fs.existsSync(path.join(base, 'openclaw.json'))) {
  console.error(`✘ No encuentro ${base}/openclaw.json. ¿Estás dentro del contenedor de OpenClaw?`);
  process.exit(1);
}

// 1. Datos
if (fs.existsSync(path.join(dataDir, 'config', 'reglas.json'))) {
  ok(`Datos ya existentes en ${dataDir}: no se sobrescriben.`);
} else {
  fs.cpSync(path.join(aqui, 'plantilla-datos'), dataDir, { recursive: true });
  ok(`Datos copiados a ${dataDir}`);
}

// 2. Propietario
const rutaReglas = path.join(dataDir, 'config', 'reglas.json');
const reglas = JSON.parse(fs.readFileSync(rutaReglas, 'utf8'));
if (a.numero) reglas.propietario.numeros = [a.numero.replace(/\s+/g, '')];
if (a.email) reglas.propietario.email = a.email;
if (a.telefono) reglas.propietario.telefono = a.telefono;
fs.writeFileSync(rutaReglas, JSON.stringify(reglas, null, 2) + '\n');
const pendientes = JSON.stringify(reglas.propietario).match(/<<SUSTITUIR_[^>]*>>/g);
if (pendientes) console.log(`⚠ Faltan valores en reglas.json: ${pendientes.join(', ')}  (repite el comando con --numero/--email/--telefono)`);
else ok(`Propietario: ${reglas.propietario.numeros.join(', ')} · ${reglas.propietario.email} · ${reglas.propietario.telefono}`);

// 3. Prompt de sistema
fs.mkdirSync(workspace, { recursive: true });
const agents = path.join(workspace, 'AGENTS.md');
if (fs.existsSync(agents) && !fs.existsSync(agents + '.bak')) fs.copyFileSync(agents, agents + '.bak');
fs.copyFileSync(path.join(aqui, 'workspace', 'AGENTS.md'), agents);
ok('AGENTS.md instalado (copia anterior en AGENTS.md.bak)');
const boot = path.join(workspace, 'BOOTSTRAP.md');
if (fs.existsSync(boot)) { fs.renameSync(boot, boot + '.bak'); ok('BOOTSTRAP.md apartado'); }

// 4. Siguientes comandos
const plugin = path.join(aqui, 'plugin');
console.log(`
Ahora ejecuta (uno a uno, desde la carpeta donde funciona "node dist/index.js"):

  node dist/index.js plugins install --link ${plugin} --force
  node dist/index.js plugins enable asistente-jon
  node dist/index.js config set plugins.entries.asistente-jon.hooks.allowConversationAccess true
  node dist/index.js config set plugins.entries.asistente-jon.config.dataDir "${dataDir}"
  node dist/index.js config set plugins.entries.asistente-jon.config.hook before_agent_reply
  node dist/index.js config set plugins.entries.asistente-jon.config.debug true
  node dist/index.js plugins inspect asistente-jon --runtime --json

Y después: Restart del servicio en Easypanel.`);
