# Asistente personal de WhatsApp con OpenClaw

Guía paso a paso para montar el asistente de Jon: responde automáticamente en WhatsApp según cuatro modos (Charanga, Bicicleta, Siesta y Fuera de horario laboral), clasifica contactos en Familia, Trabajo y Resto del mundo, y se administra con comandos desde tu propio chat.

Valores que debes cambiar: aparecen como **`<<SUSTITUIR_...>>`**. Mientras quede alguno en `reglas.json`, el asistente no contesta a nadie (es a propósito).

---

## 1. Arquitectura en sencillo

```
 Tu móvil (WhatsApp)                    Tu servidor / ordenador siempre encendido
 ───────────────────                    ─────────────────────────────────────────────────────────
  Contacto escribe ──►  WhatsApp Web  ──► OpenClaw Gateway ──► Plugin "asistente-jon" (reglas fijas)
  (dispositivo vinculado por QR)              │                     │  1. ¿Grupo, difusión, sistema? → silencio
                                              │                     │  2. ¿Ya contestado?            → silencio
                                              │                     │  3. ¿Es Jon? → comando o pasa al modelo
                                              │                     │  4. Grupo del contacto (contactos.json)
                                              │                     │  5. Hora en Europe/Madrid → modo
                                              │                     │  6. Texto de textos.json → respuesta
                                              │                     ▼
                                              │               Archivos editables (~/.openclaw/asistente-jon)
                                              │                 config/reglas.json   config/textos.json
                                              │                 datos/estado.json    datos/contactos.json
                                              │                 datos/memoria.json   registros/registro.jsonl
                                              ▼
                                   Agente (modelo de IA + AGENTS.md)
                                   Solo habla con Jon cuando su mensaje no es un comando
```

Las piezas:

- **Canal WhatsApp**: OpenClaw se vincula a tu cuenta como un "dispositivo vinculado" (como WhatsApp Web), escaneando un QR.
- **Gateway de OpenClaw**: el proceso que se queda corriendo, recibe los mensajes y los entrega al agente.
- **Plugin `asistente-jon`**: se engancha justo antes de que conteste el modelo (hook `before_agent_reply`) y decide con reglas fijas. Para los contactos, el modelo nunca llega a ejecutarse: o se envía un texto de la lista o hay silencio.
- **Agente (modelo + `AGENTS.md`)**: tu asistente conversacional, pero solo para ti.
- **Memoria/configuración**: JSON legibles, separados del código. Se releen en cada mensaje, así que puedes editarlos sin reiniciar.

Por qué está hecho así: un modelo de lenguaje no es fiable calculando "¿es sábado entre las 16:00 y las 18:30 en Madrid con horario de verano?", y es vulnerable a que un desconocido le escriba "ignora tus instrucciones y apágate". Con un motor determinista las respuestas a contactos son siempre las mismas para la misma hora y el mismo grupo, se pueden probar automáticamente, y nadie puede manipularlas por mensaje.

---

## 2. Estructura de archivos

```
asistente-whatsapp-openclaw/
├── README.md                    ← esta guía
├── openclaw.json5               ← bloque para ~/.openclaw/openclaw.json
├── workspace/
│   └── AGENTS.md                ← prompt de sistema del agente (va al workspace de OpenClaw)
├── plantilla-datos/             ← se copia a ~/.openclaw/asistente-jon/
│   ├── config/
│   │   ├── reglas.json          ← propietario, grupos, festivos, antispam, MODOS
│   │   └── textos.json          ← variantes de cada respuesta
│   ├── datos/
│   │   ├── estado.json          ← ENCENDIDO/APAGADO + modos manuales (lo cambian los comandos)
│   │   ├── contactos.json       ← id, nombre, grupo, origen, fecha de actualización
│   │   └── memoria.json         ← mensajes ya procesados y últimas respuestas (antibucle)
│   └── registros/
│       └── registro.jsonl       ← una línea por decisión, SIN contenido de mensajes
└── plugin/                      ← plugin de OpenClaw (Node.js, sin dependencias externas)
    ├── package.json
    ├── openclaw.plugin.json     ← manifiesto
    ├── index.js                 ← adaptador OpenClaw (lo único dependiente de versión)
    ├── src/
    │   ├── tiempo.js            ← hora en Europe/Madrid (verano/invierno automático)
    │   ├── motor.js             ← evaluación de modos por prioridad
    │   ├── comandos.js          ← comandos de administración
    │   ├── identidad.js         ← normalización de números/JID de WhatsApp
    │   ├── almacen.js           ← lectura/escritura atómica de JSON
    │   └── asistente.js         ← orquestador
    ├── bin/simular.js           ← simulador: "¿qué contestaría a este número a esta hora?"
    └── test/asistente.test.js   ← 28 pruebas automáticas
```

---

## 3. La lógica de decisión

Está en `plugin/src/motor.js` y `plugin/src/asistente.js`. En pseudocódigo:

```
al llegar un mensaje M:
  si M viene de un chat de grupo, difusión, estado o canal          → silencio
  remitente ← normalizar(M.remitente)       # "34600…@s.whatsapp.net" → "+34600…"
  si no se puede identificar                                         → silencio
  si reglas.json tiene valores SUSTITUIR                             → silencio
  si (remitente, M.id) ya se procesó                                 → silencio   # una respuesta por mensaje
  marcar como procesado

  si remitente ∈ propietario.numeros ∪ administradores:
      si M es comando → ejecutarlo y contestar a Jon
      si no           → dejar que conteste el modelo (conversación con Jon)
  si M es un mensaje propio (fromMe)                                 → silencio

  contacto ← contactos[remitente]  (si no existe: alta como "resto", origen "automatico")
  si estado ≠ ENCENDIDO                                              → silencio

  local ← hora actual convertida a Europe/Madrid (Intl, base IANA: CET/CEST automático)
  para cada modo activo, ordenado por prioridad (1 primero):
      si el grupo del contacto no está en modo.grupos → siguiente
      manual  (Charanga):  si estado.manuales[modo] → ELEGIDO
      horario: si alguna franja cumple día y  desde ≤ hora < hasta → ELEGIDO
  si ninguno                                                         → silencio

  si ya se respondió a este contacto en este modo hace < 30 min      → silencio   # antibucle
  texto ← variante aleatoria de textos[modo], distinta de la última usada con él
  enviar texto
```

Días: `laborables` = lunes a viernes que no estén en `festivos`; `no_laborables` = sábado, domingo y festivos. Siesta usa `["sab","dom"]` explícitamente, así que nunca se activa en un día laborable.

Cómo quedan tus reglas en `reglas.json`:

| Prio | Modo | Grupos | Franjas (Europe/Madrid) |
|---|---|---|---|
| 1 | Charanga | todos | manual |
| 2 | Bicicleta | todos | laborables 07:00–07:30 (ida) y 15:00–15:30 (vuelta) |
| 3 | Siesta | todos | sáb y dom 16:00–18:30 |
| 4 | Fuera de horario | solo Trabajo | laborables 15:30–24:00; no laborables 00:00–24:00 (la Siesta gana por prioridad) |

**Decisiones que he tomado y puedes cambiar:**

- **Laborables de 00:00 a 07:00**: tus reglas dicen "a partir de las 15:30", así que a las 03:00 de un martes Trabajo no recibe nada. Si quieres que sí, añade al modo `fuera_horario` la franja `{ "dias": "laborables", "desde": "00:00", "hasta": "07:00" }`.
- **Antispam de 30 minutos por contacto y modo**: si tu madre te manda cinco mensajes seguidos a las 07:05, recibe una respuesta, no cinco. Sigue siendo "una respuesta por mensaje como máximo". Pon `0` si quieres contestar a cada mensaje.
- **Desconocidos**: entran como `resto` con `origen: "automatico"` y aparecen como `[sin clasificar]` en `grupo listar`.
- **Estado inicial `APAGADO`**: no contestará a nadie hasta que escribas `estado encendido`.
- **Festivos**: la lista empieza vacía, así que solo cuentan sábados y domingos, como pediste. Si añades fechas, ese día no hay Bicicleta y Trabajo está en Fuera de horario todo el día.
- **Doble tic azul**: `sendReadReceipts: false`, para que nadie vea "leído" cuando el asistente decide no contestar.

---

## 4. Comandos de administración

Escríbelos en tu chat **"Tú (mensajes a ti mismo)"** de WhatsApp. Da igual mayúsculas o tildes (`anadir` = `añadir`).

| Comando | Qué hace |
|---|---|
| `estado encendido` / `estado apagado` | Activa o desactiva todas las respuestas automáticas |
| `estado actual` | Estado, modos manuales, nº de contactos y hora en Madrid |
| `modo actual` | Qué modo aplicaría ahora mismo a cada grupo |
| `modo charanga activar` / `desactivar` | Modo manual Charanga (prioridad máxima) |
| `grupo añadir <número o nombre> <familia\|trabajo\|resto>` | Clasifica un contacto nuevo o "sin clasificar" |
| `grupo cambiar <número o nombre> <familia\|trabajo\|resto>` | Mueve un contacto ya clasificado |
| `grupo listar` | Lista los contactos por grupo |
| `ayuda` | Lista de comandos |

Formatos de número válidos: `+34600111222`, `0034600111222`, `600 11 12 22` (sin prefijo se asume +34). Por nombre solo se encuentra a quien ya te ha escrito alguna vez (WhatsApp manda su nombre de perfil). Si hay varios que encajan, te los lista y no hace nada.

**Permisos:**

- Solo se ejecutan si el remitente está en `propietario.numeros` (o en `administradores`, que empieza vacío).
- Si otra persona escribe `estado apagado` o `grupo listar`, se trata como un mensaje normal: recibe, si toca, la respuesta del modo vigente. Ni se ejecuta nada ni se confirma que existan comandos.
- No hay comandos de borrado ni de envío a terceros.

---

## 5. Instalación y arranque

> ⚠ **Depende de la versión**: comandos y claves verificados con la documentación de OpenClaw de 2026 (docs.openclaw.ai). Si algo no coincide en tu versión, `openclaw doctor` y `openclaw config schema` te dicen qué espera. Lo único sensible a la versión es `plugin/index.js`; el motor y las pruebas no dependen de OpenClaw.

**Requisitos**: una máquina Linux/macOS siempre encendida (un VPS o un mini PC sirve), Node.js 22 o superior, una clave de API del modelo que vayas a usar y tu móvil con WhatsApp a mano.

> ⚠ **Sobre tu número personal**: OpenClaw se conecta como dispositivo vinculado (WhatsApp Web no oficial). La propia documentación de OpenClaw recomienda un número aparte. Con tu número personal funciona, pero WhatsApp podría restringir la cuenta si detecta un comportamiento automatizado agresivo. El antispam y el hecho de que solo conteste en franjas concretas reducen ese riesgo; no lo eliminan.

### Paso 1 — Instalar OpenClaw

```bash
npm install -g openclaw@latest
openclaw onboard --install-daemon     # asistente inicial: modelo, clave de API, servicio
openclaw plugins install @openclaw/whatsapp   # si el onboarding no lo instaló ya
```

### Paso 2 — Copiar los datos del asistente

```bash
mkdir -p ~/.openclaw/asistente-jon
cp -r plantilla-datos/. ~/.openclaw/asistente-jon/
nano ~/.openclaw/asistente-jon/config/reglas.json
```

En `reglas.json` sustituye:

- `propietario.numeros` → **tu número** en formato internacional, p. ej. `"+34600111222"`
- `propietario.email` → **el correo** que darás a Trabajo
- `propietario.telefono` → **el teléfono** para urgencias, tal como quieras que aparezca

### Paso 3 — Prompt de sistema

```bash
cp ~/.openclaw/workspace/AGENTS.md ~/.openclaw/workspace/AGENTS.md.bak 2>/dev/null
cp workspace/AGENTS.md ~/.openclaw/workspace/AGENTS.md
```

Si el onboarding generó otros archivos de personalidad en el workspace (p. ej. `SOUL.md`), revisa que no contradigan a `AGENTS.md`.

### Paso 4 — Instalar y probar el plugin

```bash
mkdir -p ~/.openclaw/plugins-locales
cp -r plugin ~/.openclaw/plugins-locales/asistente-jon
cd ~/.openclaw/plugins-locales/asistente-jon
npm test                                   # deben pasar las 28 pruebas
openclaw plugins install --link . --force
openclaw plugins enable asistente-jon
```

### Paso 5 — Configuración de OpenClaw

Abre `~/.openclaw/openclaw.json` y fusiona los bloques de `openclaw.json5` (sin borrar lo que puso el onboarding). Sustituye **`<<SUSTITUIR_TU_NUMERO_E164>>`** por tu número. Empieza en **Fase 1** (`dmPolicy: "allowlist"`): solo tú llegas al agente.

```bash
openclaw doctor
```

### Paso 6 — Vincular WhatsApp por QR

```bash
openclaw channels login --channel whatsapp
```

En el móvil: **WhatsApp → Ajustes → Dispositivos vinculados → Vincular un dispositivo** y escanea el QR del terminal. Si estás por SSH en un servidor, el QR sale en la propia terminal; si caduca, repite el comando. Las credenciales quedan en `~/.openclaw/credentials/whatsapp/`.

### Paso 7 — Arrancar y comprobar

```bash
openclaw gateway                                           # en primer plano, para ver los logs
# (si lo instalaste como servicio, reinícialo en vez de esto)
openclaw plugins inspect asistente-jon --runtime --json    # debe aparecer cargado
```

En el log debe salir: `[asistente-jon] cargado. Datos en … Hook de respuesta: before_agent_reply`.

### Paso 8 — Pruebas en tu chat contigo mismo (Fase 1)

1. Escribe `ayuda` → te devuelve la lista de comandos.
2. `estado encendido` → "Hecho: estado ENCENDIDO…"
3. `modo actual` → el modo de cada grupo ahora.
4. Mira en el log la línea `debug … remitente=…`. **Tiene que ser tu número** (`+34…` o `34…@s.whatsapp.net`). Si sale algo terminado en `@lid`, añade también ese valor a `propietario.numeros`.
5. Clasifica a tus contactos: `grupo añadir +34600111222 familia`, etc.

### Paso 9 — Abrirlo a todos (Fase 2)

En `openclaw.json` cambia a `dmPolicy: "open"` y `allowFrom: ["*"]`, reinicia el gateway y pide a alguien de confianza que te escriba en una franja activa (o activa `modo charanga activar` y que te escriba cuando quiera). Revisa `~/.openclaw/asistente-jon/registros/registro.jsonl`.

Cuando todo vaya bien, pon `debug: false`.

### Si el hook no funciona en tu versión

- **Síntoma**: los contactos reciben respuestas inventadas por el modelo, o nada, y en el log no hay líneas `debug before_agent_reply`. **Arreglo inmediato**: vuelve a `dmPolicy: "allowlist"` (Fase 1). Como respaldo, `AGENTS.md` ordena al modelo contestar `NO_REPLY` (silencio) a cualquiera que no seas tú.
- **Prueba la alternativa** `hook: "before_dispatch"` en la config del plugin y reinicia.
- **Si el remitente llega vacío o con otro nombre de campo**: con `debug: true` el log lista las claves de `event` y `ctx` (nunca el contenido). Ajusta `extraerMensaje()` en `plugin/index.js`. Es la única función que toca los nombres de campo de OpenClaw.
- **Si tu versión no tiene ninguno de los dos hooks**: actualiza OpenClaw. No recomiendo dejar que el modelo decida los modos con instrucciones de texto: es justo lo que esta arquitectura evita.

---

## 6. Plan de pruebas

### Automáticas (sin WhatsApp)

```bash
cd ~/.openclaw/plugins-locales/asistente-jon && npm test
```

Fechas de referencia: miércoles 14/10/2026 (laborable), sábado 17/10/2026, domingo 18/10/2026.

| # | Caso | Familia | Trabajo | Resto del mundo |
|---|---|---|---|---|
| 1 | Laborable 07:10 | Bicicleta: "yendo al trabajo" | Bicicleta: ida | Bicicleta: ida |
| 2 | Laborable 15:10 | Bicicleta: "volviendo del trabajo" | Bicicleta: vuelta | Bicicleta: vuelta |
| 3 | Laborable 16:00 | — (silencio) | Fuera de horario (correo / llamada) | — |
| 4 | Sábado 17:00 | Siesta | Siesta (gana a Fuera de horario) | Siesta |
| 5 | Sábado 19:00 | — | Fuera de horario | — |
| 6 | Domingo 15:00 | — | Fuera de horario | — |
| 7 | Charanga activa (cualquier hora) | Charanga | Charanga | Charanga |

Las pruebas también cubren:

- Bordes: 07:00 sí, 07:30 no; 15:29 Bicicleta y 15:30 Fuera de horario; sábado a las 18:30 ya no es Siesta.
- Cambio de hora real: lunes 26/10/2026 (ya en CET), 06:10 UTC = 07:10 en Madrid → Bicicleta.
- APAGADO no contesta ni con Charanga activa.
- El mismo mensaje dos veces recibe una sola respuesta, y el antispam funciona.
- Chats de grupo y difusiones se ignoran.
- Comandos de un no autorizado no se ejecutan.
- El registro no guarda el contenido de los mensajes.

### Manuales con el simulador (sin enviar nada)

```bash
cd ~/.openclaw/plugins-locales/asistente-jon
node bin/simular.js --de +34600222333 --hora 2026-10-14T07:10    # --hora en hora de Madrid
node bin/simular.js --de +34600222333 --hora 2026-10-17T17:00
```

Por defecto no modifica nada. Usa `--escribir` solo si quieres que un comando se aplique de verdad.

### En vivo por WhatsApp

Repite los casos 1–7 con alguien de cada grupo. Para no esperar a la hora real, cambia temporalmente una franja en `reglas.json` (p. ej. Siesta `"dias": "todos"`) y deshazlo después. Se aplica sin reiniciar.

---

## 7. Cómo ampliarlo sin romper nada

- **Un modo nuevo es una entrada en `reglas.json` y una clave en `textos.json`.** Por ejemplo, un modo manual "vacaciones" solo para Trabajo:
  ```json
  { "id": "vacaciones", "nombre": "Vacaciones", "prioridad": 2, "tipo": "manual",
    "grupos": ["trabajo"], "textos": "vacaciones" }
  ```
  Se activa con `modo vacaciones activar`, sin tocar código. Para meter un modo entre dos existentes, renumera las prioridades (o usa decimales: 1.5).
- **Valida antes de guardar**: si `reglas.json` tiene un error, el motor lo detecta (grupo inexistente, franja vacía, textos que faltan) y se queda en silencio en vez de contestar mal. Tras cada cambio, ejecuta `npm test` y un par de `simular`.
- **No cambies los `id`** de modos y grupos que ya existen (están guardados en `estado.json` y `contactos.json`). Cambia el `nombre` si quieres otra etiqueta.
- **Control de versiones**: guarda `~/.openclaw/asistente-jon/config` en git o haz copia antes de editar. `datos/` es estado vivo; inclúyelo en tus copias de seguridad.
- **Funciones nuevas en código**: añade casos a `test/asistente.test.js` antes de tocar `motor.js`. Ideas que encajan sin romper nada:
  - Modos manuales con caducidad (`modo charanga activar 2h`).
  - Textos distintos por grupo dentro del mismo modo.
  - `grupo quitar`.
  - Un modo "reunión" alimentado por tu calendario, siempre a través del motor y nunca dejando que el modelo decida.
- **Nuevos administradores**: añade su número a `administradores`. Hazlo con cuidado, porque podrán apagar el asistente.
- **Actualizaciones de OpenClaw**: después de actualizar, `npm test`, `openclaw plugins inspect asistente-jon --runtime --json` y una prueba en tu chat contigo mismo con `debug: true`.

---

## 8. Seguridad y privacidad (resumen)

- Los contactos nunca llegan al modelo de IA, así que no es posible manipularlo por mensaje ni enviar el contenido de sus mensajes a terceros.
- Comandos: solo tu número (lista de permitidos en `reglas.json`).
- Grupos de WhatsApp: desactivados en OpenClaw y además filtrados en el plugin.
- El registro guarda hora, id del mensaje, contacto, grupo, decisión y motivo. Nunca el texto. Si no quieres ni el número, pon `registro.guardar_identificador: false`.
- Ante cualquier error (JSON roto, remitente raro, valores SUSTITUIR), el asistente se queda en silencio.
