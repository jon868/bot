// Adaptador OpenClaw -> motor del asistente.
//
// Idea clave: TODA decisión sobre contactos la toma este plugin de forma determinista,
// ANTES de que se ejecute el modelo (hook `before_agent_reply`). El LLM solo entra
// cuando escribe el propietario y su mensaje no es un comando.
//
// ⚠ Dependiente de versión: los nombres de campos de `event`/`ctx` en los hooks pueden
// variar entre versiones de OpenClaw. Por eso se leen de forma defensiva y existe
// `debug: true` para registrar qué campos llegan (nunca el contenido).
import os from 'node:os';
import path from 'node:path';
import { definePluginEntry } from 'openclaw/plugin-sdk/plugin-entry';
import { crearAsistente } from './src/asistente.js';

const ID = 'asistente-jon';
const recientes = new Map(); // messageId|sessionKey -> datos del mensaje entrante (TTL corto)
const TTL_MS = 5 * 60 * 1000;

const primero = (...valores) => valores.find((v) => v !== undefined && v !== null && v !== '');

function recordar(clave, datos) {
  if (!clave) return;
  recientes.set(clave, { ...datos, t: Date.now() });
  for (const [k, v] of recientes) if (Date.now() - v.t > TTL_MS) recientes.delete(k);
}

function esWhatsApp(ctx = {}, event = {}) {
  const canal = primero(ctx.channel, ctx.messageProvider, ctx.provider, ctx.channelType, event.channel);
  if (!canal) return true; // si no se puede saber, asumimos WhatsApp (es el único canal configurado)
  return String(typeof canal === 'object' ? canal.id || canal.type : canal).toLowerCase().includes('whatsapp');
}

function extraerMensaje(event = {}, ctx = {}) {
  const guardado = recientes.get(primero(ctx.messageId, event.messageId)) || recientes.get(ctx.sessionKey) || {};
  const remitente = primero(guardado.remitente, ctx.senderId, event.senderId, event.from, ctx.from, event.sender?.id);
  const sessionKey = String(primero(ctx.sessionKey, '') || '');
  return {
    id: primero(guardado.id, ctx.messageId, event.messageId),
    remitente,
    nombre: primero(guardado.nombre, ctx.senderName, event.senderName, typeof event.sender === 'object' ? event.sender?.name : undefined),
    texto: primero(guardado.texto, event.content, event.body, event.cleanedBody, ''),
    esGrupo: Boolean(primero(guardado.esGrupo, ctx.isGroup, event.isGroup)) || sessionKey.includes(':group:') || /@g\.us$/.test(String(remitente || '')),
    esPropio: Boolean(primero(guardado.esPropio, ctx.fromMe, event.fromMe, event.metadata?.fromMe)),
  };
}

function aRespuesta(resultado, formato) {
  if (resultado.accion === 'pasar_al_llm') return undefined; // el modelo responde (solo propietario)
  if (resultado.accion === 'responder') {
    return formato === 'before_dispatch'
      ? { handled: true, text: resultado.texto }
      : { handled: true, reply: { text: resultado.texto } };
  }
  return { handled: true }; // silencio: no se llama al modelo ni se envía nada
}

export default definePluginEntry({
  id: ID,
  name: 'Asistente personal de Jon',
  description: 'Respuestas automáticas por modos (Charanga, Bicicleta, Siesta, Fuera de horario) y comandos de administración.',
  register(api) {
    const cfg = primero(api.pluginConfig, api.config?.plugins?.entries?.[ID]?.config, {}) || {};
    const dataDir = (cfg.dataDir || process.env.ASISTENTE_JON_DIR || path.join(os.homedir(), '.openclaw', 'asistente-jon'))
      .replace(/^~(?=$|\/)/, os.homedir());
    const hook = cfg.hook === 'before_dispatch' ? 'before_dispatch' : 'before_agent_reply';
    const log = (m) => (api.logger?.info ? api.logger.info(`[${ID}] ${m}`) : console.log(`[${ID}] ${m}`));
    const asistente = crearAsistente({ dataDir, log });
    log(`cargado. Datos en ${dataDir}. Hook de respuesta: ${hook}`);

    // 1) Capturamos el mensaje en bruto (texto real, remitente, id) al llegar.
    api.on('message_received', (event = {}, ctx = {}) => {
      const datos = {
        id: primero(event.messageId, ctx.messageId),
        remitente: primero(event.senderId, ctx.senderId, event.from),
        nombre: primero(event.senderName, typeof event.sender === 'object' ? event.sender?.name : event.sender),
        texto: primero(event.content, event.body, ''),
        esGrupo: primero(event.isGroup, event.metadata?.isGroup, ctx.isGroup),
        esPropio: primero(event.fromMe, event.metadata?.fromMe),
      };
      recordar(datos.id, datos);
      recordar(ctx.sessionKey, datos);
      if (cfg.debug) log(`debug message_received event=[${Object.keys(event)}] ctx=[${Object.keys(ctx)}] senderId=${datos.remitente}`);
    });

    // 2) Antes de que el modelo conteste, decidimos nosotros.
    api.on(hook, (event = {}, ctx = {}) => {
      if (!esWhatsApp(ctx, event)) return undefined;
      const msg = extraerMensaje(event, ctx);
      if (cfg.debug) log(`debug ${hook} event=[${Object.keys(event)}] ctx=[${Object.keys(ctx)}] remitente=${msg.remitente} grupo=${msg.esGrupo}`);
      try {
        const r = asistente.procesar(msg, new Date());
        if (cfg.debug) log(`debug decision=${r.accion} motivo=${r.motivo || ''} modo=${r.modo || ''}`);
        return aRespuesta(r, hook);
      } catch (e) {
        log(`ERROR: ${e.message}. Por seguridad no se responde.`);
        return { handled: true }; // fallo seguro: ante la duda, silencio
      }
    }, { eligibleTriggers: ['user'] });
  },
});
