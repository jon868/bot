// Normalización de identificadores de WhatsApp.
//  "34600111222@s.whatsapp.net"       -> { tipo: 'telefono', id: '+34600111222' }
//  "34600111222:12@s.whatsapp.net"    -> idem (sufijo de dispositivo)
//  "+34 600 11 12 22" / "0034600111222" / "600111222" -> '+34600111222'
//  "1234567890@lid"                   -> { tipo: 'lid', id: '1234567890@lid' }  (ID anónimo de WhatsApp)
//  "...@g.us", "status@broadcast", "...@newsletter" -> { tipo: 'no_humano' }

export function normalizarId(bruto, prefijoPais = '34') {
  if (bruto === undefined || bruto === null) return null;
  let s = String(bruto).trim();
  if (!s) return null;
  if (/@g\.us$|@broadcast$|@newsletter$|^status@/i.test(s)) return { tipo: 'no_humano', id: s };
  if (/@lid$/i.test(s)) return { tipo: 'lid', id: s.replace(/:\d+@/, '@').toLowerCase() };

  s = s.replace(/^whatsapp:/i, '').replace(/@(s\.whatsapp\.net|c\.us)$/i, '').replace(/:\d+$/, '');
  if (/[a-z]/i.test(s)) return null; // contiene letras: no es un número
  const internacional = /^\s*(\+|00)/.test(s);
  let d = s.replace(/\D/g, '');
  if (d.startsWith('00')) d = d.slice(2);
  if (!/^\d{6,15}$/.test(d)) return null;
  if (!internacional && d.length === 9 && prefijoPais) d = prefijoPais + d; // número nacional español
  return { tipo: 'telefono', id: '+' + d };
}

/** Quita tildes y pasa a minúsculas para comparar comandos y nombres. */
export function plano(texto) {
  return String(texto || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/\s+/g, ' ').trim();
}
