// Orquestador: recibe un mensaje entrante normalizado y devuelve qué hacer.
//   { accion: 'responder', texto }   -> enviar ese texto (una sola vez)
//   { accion: 'ignorar', motivo }    -> silencio total (el LLM no se ejecuta)
//   { accion: 'pasar_al_llm' }       -> solo para el propietario cuando no es un comando
import path from 'node:path';
import { leerJSON, escribirJSON, anotarLinea } from './almacen.js';
import { horaLocal } from './tiempo.js';
import { evaluarModo, validarReglas } from './motor.js';
import { normalizarId } from './identidad.js';
import { ejecutarComando } from './comandos.js';

const ESTADO_INICIAL = { estado: 'APAGADO', manuales: {}, actualizado: null };
const CONTACTOS_INICIAL = { contactos: {} };
const MEMORIA_INICIAL = { procesados: [], ultimas: {} };
const MAX_PROCESADOS = 2000;

export function crearAsistente({ dataDir, soloLectura = false, aleatorio = Math.random, log = () => {} }) {
  const rutas = {
    reglas: path.join(dataDir, 'config', 'reglas.json'),
    textos: path.join(dataDir, 'config', 'textos.json'),
    contactos: path.join(dataDir, 'datos', 'contactos.json'),
    estado: path.join(dataDir, 'datos', 'estado.json'),
    memoria: path.join(dataDir, 'datos', 'memoria.json'),
    registro: path.join(dataDir, 'registros', 'registro.jsonl'),
  };
  const escribir = (ruta, datos) => { if (!soloLectura) escribirJSON(ruta, datos); };

  /**
   * msg = { id, remitente, nombre, texto, esGrupo, esPropio }
   *  - remitente: JID o número tal como llegue del canal
   *  - esGrupo:   true si viene de un chat de grupo
   *  - esPropio:  true si es un mensaje enviado desde la propia cuenta (fromMe)
   */
  function procesar(msg, ahora = new Date()) {
    // Las reglas y textos se leen en cada mensaje: si los editas, se aplican sin reiniciar.
    const reglas = leerJSON(rutas.reglas);
    const textos = leerJSON(rutas.textos);
    validarReglas(reglas, textos);
    const local = horaLocal(ahora, reglas.zona_horaria || 'Europe/Madrid');

    let contactoId = null;
    let grupo = null;
    const terminar = (resultado) => {
      if (!soloLectura) {
        anotarLinea(rutas.registro, {
          ts: ahora.toISOString(),
          local: `${local.fechaISO} ${local.hora} ${local.dia}`,
          msg: msg.id || null,
          contacto: reglas.registro?.guardar_identificador === false ? undefined : contactoId,
          grupo,
          accion: resultado.accion,
          modo: resultado.modo,
          motivo: resultado.motivo,
          // Nunca se guarda el contenido del mensaje.
        });
      }
      return resultado;
    };
    const ignorar = (motivo) => terminar({ accion: 'ignorar', motivo });

    // 1. Filtros de origen: grupos, difusiones, sistema, remitentes no identificables.
    if (msg.esGrupo) return ignorar('chat_de_grupo');
    const rem = normalizarId(msg.remitente, reglas.prefijo_pais_por_defecto);
    if (!rem) return ignorar('remitente_no_identificable');
    if (rem.tipo === 'no_humano') return ignorar('no_humano');
    contactoId = rem.id;

    // 2. Configuración sin rellenar -> silencio (fallo seguro).
    if (JSON.stringify(reglas).includes('<<SUSTITUIR_')) {
      log('reglas.json contiene valores <<SUSTITUIR_...>>: el asistente se queda en silencio.');
      return ignorar('configuracion_incompleta');
    }

    // 3. Deduplicación persistente: una sola respuesta por mensaje.
    const memoria = leerJSON(rutas.memoria, MEMORIA_INICIAL);
    const clave = `${rem.id}|${msg.id || `sin-id:${String(msg.texto || '').slice(0, 40)}:${Math.floor(ahora.getTime() / 60000)}`}`;
    if (memoria.procesados.includes(clave)) return ignorar('duplicado');
    memoria.procesados.push(clave);
    if (memoria.procesados.length > MAX_PROCESADOS) memoria.procesados.splice(0, memoria.procesados.length - MAX_PROCESADOS);
    escribir(rutas.memoria, memoria);

    // 4. Propietario / administradores: comandos.
    const autorizados = new Set(
      [...(reglas.propietario?.numeros || []), ...(reglas.administradores || [])]
        .map((n) => normalizarId(n, reglas.prefijo_pais_por_defecto)?.id).filter(Boolean),
    );
    const esPropietario = autorizados.has(rem.id);
    if (esPropietario) {
      grupo = 'propietario';
      const ctx = {
        reglas, textos, local, ahoraISO: ahora.toISOString(),
        leerEstado: () => leerJSON(rutas.estado, ESTADO_INICIAL),
        guardarEstado: (e) => escribir(rutas.estado, e),
        leerContactos: () => leerJSON(rutas.contactos, CONTACTOS_INICIAL),
        guardarContactos: (d) => escribir(rutas.contactos, d),
      };
      const respuesta = ejecutarComando(msg.texto, ctx);
      if (respuesta) return terminar({ accion: 'responder', texto: respuesta, motivo: 'comando' });
      return reglas.propietario?.pasar_al_llm
        ? terminar({ accion: 'pasar_al_llm', motivo: 'propietario_conversa' })
        : ignorar('propietario_sin_comando');
    }
    if (msg.esPropio) return ignorar('mensaje_propio');
    // Un no autorizado que escribe "estado apagado" es un mensaje normal: no se ejecuta ni se revela nada.

    // 5. Registro mínimo del contacto (alta automática en el grupo por defecto).
    const datos = leerJSON(rutas.contactos, CONTACTOS_INICIAL);
    let contacto = datos.contactos[rem.id];
    if (!contacto) {
      contacto = { id: rem.id, nombre: msg.nombre || null, grupo: reglas.grupo_por_defecto, origen: 'automatico', actualizado: ahora.toISOString() };
      datos.contactos[rem.id] = contacto;
      escribir(rutas.contactos, datos);
    } else if (msg.nombre && !contacto.nombre) {
      contacto.nombre = msg.nombre;
      contacto.actualizado = ahora.toISOString();
      escribir(rutas.contactos, datos);
    }
    grupo = contacto.grupo;
    if (!reglas.grupos[grupo]) return ignorar('grupo_desconocido');

    // 6. Modo vigente.
    const estado = leerJSON(rutas.estado, ESTADO_INICIAL);
    const decision = evaluarModo({ grupo, estado, reglas, local });
    if (!decision.responder) return ignorar(decision.motivo);

    // 7. Antibucle / antispam: como mucho una respuesta por contacto y modo cada X minutos.
    const minutos = reglas.antispam?.minutos_entre_respuestas ?? 30;
    const claveUltima = `${rem.id}|${decision.modo}`;
    const ultima = memoria.ultimas[claveUltima];
    if (ultima && ahora.getTime() - ultima.ts < minutos * 60000) {
      return terminar({ accion: 'ignorar', motivo: 'ya_respondido_hace_poco', modo: decision.modo });
    }

    // 8. Texto: variante aleatoria distinta de la última usada con ese contacto.
    const variantes = textos[decision.textos];
    let indice = Math.floor(aleatorio() * variantes.length);
    if (variantes.length > 1 && ultima && indice === ultima.indice) indice = (indice + 1) % variantes.length;
    const texto = rellenar(variantes[indice], reglas.propietario);

    memoria.ultimas[claveUltima] = { ts: ahora.getTime(), indice };
    for (const [k, v] of Object.entries(memoria.ultimas)) if (ahora.getTime() - v.ts > 3 * 86400000) delete memoria.ultimas[k];
    escribir(rutas.memoria, memoria);

    return terminar({ accion: 'responder', texto, modo: decision.modo });
  }

  return { procesar, rutas };
}

function rellenar(plantilla, propietario = {}) {
  return plantilla.replace(/\{(\w+)\}/g, (todo, clave) => (propietario[clave] !== undefined ? String(propietario[clave]) : todo));
}
