// Comandos de administración. SOLO se llaman cuando el remitente es el propietario
// (o un administrador listado en reglas.json). La comprobación se hace en asistente.js.
import { evaluarModo } from './motor.js';
import { normalizarId, plano } from './identidad.js';

const PALABRAS_CLAVE = new Set(['estado', 'modo', 'grupo', 'ayuda']);

export const AYUDA = [
  'Comandos disponibles:',
  '• estado encendido | estado apagado',
  '• estado actual',
  '• modo actual',
  '• modo charanga activar | modo charanga desactivar',
  '• grupo añadir <número o nombre> <familia|trabajo|resto>',
  '• grupo cambiar <número o nombre> <familia|trabajo|resto>',
  '• grupo listar',
  '• ayuda',
].join('\n');

/**
 * Devuelve el texto de respuesta si `texto` es un comando, o null si no lo es
 * (en ese caso el mensaje del propietario puede pasar al LLM).
 */
export function ejecutarComando(texto, c) {
  const original = String(texto || '').trim();
  const tokens = original.split(/\s+/);
  const p = tokens.map(plano);
  if (!p[0] || !PALABRAS_CLAVE.has(p[0])) return null;

  // ---- ayuda
  if (p[0] === 'ayuda' && p.length === 1) return AYUDA;

  // ---- estado
  if (p[0] === 'estado' && p.length === 2) {
    if (p[1] === 'encendido' || p[1] === 'apagado') {
      const estado = c.leerEstado();
      estado.estado = p[1] === 'encendido' ? 'ENCENDIDO' : 'APAGADO';
      estado.actualizado = c.ahoraISO;
      c.guardarEstado(estado);
      return estado.estado === 'ENCENDIDO'
        ? 'Hecho: estado ENCENDIDO. Vuelvo a contestar según los modos.'
        : 'Hecho: estado APAGADO. No contestaré automáticamente a nadie.';
    }
    if (p[1] === 'actual') return resumenEstado(c);
  }

  // ---- modo
  if (p[0] === 'modo') {
    if (p.length === 2 && p[1] === 'actual') return resumenModo(c);
    if (p.length === 3 && (p[2] === 'activar' || p[2] === 'desactivar')) {
      const modo = (c.reglas.modos || []).find((m) => plano(m.id) === p[1]);
      if (!modo) return `No conozco el modo "${tokens[1]}".`;
      if (modo.tipo !== 'manual') return `El modo ${modo.nombre} es automático por horario; no se activa a mano.`;
      const estado = c.leerEstado();
      estado.manuales = estado.manuales || {};
      estado.manuales[modo.id] = p[2] === 'activar';
      estado.actualizado = c.ahoraISO;
      c.guardarEstado(estado);
      const aviso = estado.estado !== 'ENCENDIDO' ? ' Ojo: el agente está APAGADO, así que no contestará hasta que escribas "estado encendido".' : '';
      return `Hecho: modo ${modo.nombre} ${p[2] === 'activar' ? 'ACTIVADO' : 'DESACTIVADO'}.${aviso}`;
    }
  }

  // ---- grupo
  if (p[0] === 'grupo') {
    if (p.length === 2 && p[1] === 'listar') return listarGrupos(c);
    if ((p[1] === 'anadir' || p[1] === 'cambiar') && p.length >= 4) {
      const grupo = p[p.length - 1];
      if (!c.reglas.grupos[grupo]) {
        return `Grupo "${tokens[tokens.length - 1]}" no válido. Usa: ${Object.keys(c.reglas.grupos).join(', ')}.`;
      }
      const referencia = tokens.slice(2, -1).join(' ');
      const r = resolverContacto(referencia, c);
      if (r.error) return r.error;

      const datos = c.leerContactos();
      const existente = datos.contactos[r.id];
      if (p[1] === 'anadir' && existente && existente.origen === 'manual') {
        return `${etiqueta(existente)} ya está en ${c.reglas.grupos[existente.grupo].nombre}. Si quieres moverlo usa "grupo cambiar".`;
      }
      if (p[1] === 'cambiar' && !existente) {
        return `No tengo registrado a ${referencia}. Usa "grupo añadir".`;
      }
      const anterior = existente ? existente.grupo : null;
      datos.contactos[r.id] = {
        id: r.id,
        nombre: existente?.nombre || r.nombre || null,
        grupo,
        origen: 'manual',
        actualizado: c.ahoraISO,
      };
      c.guardarContactos(datos);
      const nombreGrupo = c.reglas.grupos[grupo].nombre;
      return anterior && anterior !== grupo
        ? `Hecho: ${etiqueta(datos.contactos[r.id])} pasa de ${c.reglas.grupos[anterior]?.nombre || anterior} a ${nombreGrupo}.`
        : `Hecho: ${etiqueta(datos.contactos[r.id])} está en ${nombreGrupo}.`;
    }
  }

  return `No he entendido el comando.\n\n${AYUDA}`;
}

function etiqueta(contacto) {
  return contacto.nombre ? `${contacto.nombre} (${contacto.id})` : contacto.id;
}

/** Acepta un número (cualquier formato razonable) o el nombre de un contacto ya visto. */
function resolverContacto(referencia, c) {
  const comoNumero = normalizarId(referencia, c.reglas.prefijo_pais_por_defecto);
  if (comoNumero && comoNumero.tipo !== 'no_humano') return { id: comoNumero.id };

  const buscado = plano(referencia);
  if (!buscado) return { error: 'Falta el número o el nombre del contacto.' };
  const todos = Object.values(c.leerContactos().contactos);
  const exactos = todos.filter((x) => plano(x.nombre) === buscado);
  const candidatos = exactos.length ? exactos : todos.filter((x) => plano(x.nombre).includes(buscado));
  if (candidatos.length === 1) return { id: candidatos[0].id, nombre: candidatos[0].nombre };
  if (candidatos.length === 0) {
    return { error: `No encuentro a "${referencia}". Solo conozco por nombre a quien ya me ha escrito; si no, usa su número (p. ej. +34600111222).` };
  }
  return { error: `Hay varios contactos que encajan con "${referencia}":\n${candidatos.map((x) => `• ${etiqueta(x)}`).join('\n')}\nUsa el número para no equivocarnos.` };
}

function resumenEstado(c) {
  const e = c.leerEstado();
  const datos = c.leerContactos();
  const manuales = (c.reglas.modos || []).filter((m) => m.tipo === 'manual')
    .map((m) => `${m.nombre}: ${e.manuales?.[m.id] ? 'ACTIVO' : 'inactivo'}`).join(', ');
  return [
    `Estado: ${e.estado}`,
    `Modos manuales: ${manuales || 'ninguno'}`,
    `Contactos registrados: ${Object.keys(datos.contactos).length}`,
    `Hora en ${c.local.zona}: ${c.local.fechaISO} ${c.local.hora} (${c.local.dia})`,
    `Última modificación: ${e.actualizado || '—'}`,
  ].join('\n');
}

function resumenModo(c) {
  const e = c.leerEstado();
  if (e.estado !== 'ENCENDIDO') return `El agente está APAGADO: ahora mismo no contesto a nadie. (${c.local.dia} ${c.local.hora})`;
  const lineas = Object.entries(c.reglas.grupos).map(([id, g]) => {
    const d = evaluarModo({ grupo: id, estado: e, reglas: c.reglas, local: c.local });
    const nombreModo = d.responder ? (c.reglas.modos.find((m) => m.id === d.modo)?.nombre || d.modo) : 'sin respuesta automática';
    return `• ${g.nombre}: ${nombreModo}${d.franja ? ` (${d.franja})` : ''}`;
  });
  return [`Ahora (${c.local.dia} ${c.local.hora}, ${c.local.zona}):`, ...lineas].join('\n');
}

function listarGrupos(c) {
  const todos = Object.values(c.leerContactos().contactos);
  if (!todos.length) return 'Todavía no hay contactos registrados.';
  return Object.entries(c.reglas.grupos).map(([id, g]) => {
    const miembros = todos.filter((x) => x.grupo === id)
      .sort((a, b) => (a.nombre || a.id).localeCompare(b.nombre || b.id))
      .map((x) => `  - ${etiqueta(x)}${x.origen === 'automatico' ? ' [sin clasificar]' : ''}`);
    return `${g.nombre} (${miembros.length})${miembros.length ? '\n' + miembros.join('\n') : ''}`;
  }).join('\n\n');
}
