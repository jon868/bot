// Lógica de modos: pura, sin E/S. Recibe reglas + estado + hora local y decide.
import { aMinutos } from './tiempo.js';

const FIN_DE_SEMANA = new Set(['sab', 'dom']);

/** ¿El día local encaja con la especificación de días de una franja? */
export function diaCoincide(espec, local, festivos = []) {
  const esFestivo = festivos.includes(local.fechaISO);
  const esFinde = FIN_DE_SEMANA.has(local.dia);
  if (espec === 'todos') return true;
  if (espec === 'laborables') return !esFinde && !esFestivo;      // lun-vie no festivos
  if (espec === 'no_laborables') return esFinde || esFestivo;     // sáb, dom y festivos
  if (Array.isArray(espec)) return espec.includes(local.dia);     // p. ej. ["sab","dom"]
  return false;
}

/** Franja semiabierta [desde, hasta): 07:00 entra, 07:30 ya no. */
export function enFranja(franja, local) {
  const desde = aMinutos(franja.desde);
  const hasta = aMinutos(franja.hasta);
  return local.minutos >= desde && local.minutos < hasta;
}

/**
 * Decide qué modo aplica a un remitente de un grupo dado.
 * Devuelve { responder: true, modo, textos, franja? } o { responder: false, motivo }.
 */
export function evaluarModo({ grupo, estado, reglas, local }) {
  if (!estado || estado.estado !== 'ENCENDIDO') return { responder: false, motivo: 'agente_apagado' };

  const modos = [...(reglas.modos || [])]
    .filter((m) => m.activo !== false)
    .sort((a, b) => a.prioridad - b.prioridad);           // 1 = máxima prioridad

  for (const modo of modos) {
    if (!Array.isArray(modo.grupos) || !modo.grupos.includes(grupo)) continue;

    if (modo.tipo === 'manual') {
      if (estado.manuales && estado.manuales[modo.id] === true) {
        return { responder: true, modo: modo.id, textos: modo.textos };
      }
      continue;
    }

    if (modo.tipo === 'horario') {
      for (const franja of modo.franjas || []) {
        if (diaCoincide(franja.dias, local, reglas.festivos) && enFranja(franja, local)) {
          return { responder: true, modo: modo.id, textos: franja.textos || modo.textos, franja: `${franja.desde}-${franja.hasta}` };
        }
      }
    }
  }
  return { responder: false, motivo: 'ningun_modo_aplica' };
}

/** Valida las reglas al cargarlas. Lanza error si algo es incoherente. */
export function validarReglas(reglas, textos) {
  const errores = [];
  const grupos = Object.keys(reglas.grupos || {});
  if (!grupos.length) errores.push('No hay grupos definidos');
  if (!grupos.includes(reglas.grupo_por_defecto)) errores.push('grupo_por_defecto no existe en grupos');
  const ids = new Set();
  for (const m of reglas.modos || []) {
    if (ids.has(m.id)) errores.push(`Modo duplicado: ${m.id}`);
    ids.add(m.id);
    if (!['manual', 'horario'].includes(m.tipo)) errores.push(`Modo ${m.id}: tipo desconocido`);
    for (const g of m.grupos || []) if (!grupos.includes(g)) errores.push(`Modo ${m.id}: grupo desconocido "${g}"`);
    const claves = m.tipo === 'horario' ? (m.franjas || []).map((f) => f.textos || m.textos) : [m.textos];
    for (const c of claves) if (!textos[c] || !textos[c].length) errores.push(`Modo ${m.id}: faltan textos "${c}"`);
    for (const f of m.franjas || []) {
      try { if (aMinutos(f.desde) >= aMinutos(f.hasta)) errores.push(`Modo ${m.id}: franja ${f.desde}-${f.hasta} vacía`); }
      catch (e) { errores.push(`Modo ${m.id}: ${e.message}`); }
    }
  }
  if (errores.length) throw new Error('reglas.json no válido:\n- ' + errores.join('\n- '));
}
