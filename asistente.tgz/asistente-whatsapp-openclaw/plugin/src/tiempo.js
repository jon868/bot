// Manejo explícito de zona horaria (por defecto Europe/Madrid).
// Usa la base de datos IANA del propio Node (Intl), así que los cambios
// de horario de verano/invierno (CET/CEST) se aplican solos.

const DIA_ABREV = { Sun: 'dom', Mon: 'lun', Tue: 'mar', Wed: 'mie', Thu: 'jue', Fri: 'vie', Sat: 'sab' };

/** Convierte un instante (Date) a fecha/hora local de la zona indicada. */
export function horaLocal(instante = new Date(), zona = 'Europe/Madrid') {
  const fmt = new Intl.DateTimeFormat('en-US', {
    timeZone: zona,
    year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', weekday: 'short',
    hourCycle: 'h23',
  });
  const p = Object.fromEntries(fmt.formatToParts(instante).map((x) => [x.type, x.value]));
  const hora = Number(p.hour);
  const minuto = Number(p.minute);
  return {
    zona,
    fechaISO: `${p.year}-${p.month}-${p.day}`,
    dia: DIA_ABREV[p.weekday],            // 'lun' ... 'dom'
    minutos: hora * 60 + minuto,          // minutos desde las 00:00 locales
    hora: `${p.hour}:${p.minute}`,
  };
}

/** "07:30" -> 450 ; "24:00" -> 1440 */
export function aMinutos(hhmm) {
  const m = /^(\d{1,2}):(\d{2})$/.exec(String(hhmm).trim());
  if (!m) throw new Error(`Hora no válida: "${hhmm}" (formato HH:MM)`);
  const total = Number(m[1]) * 60 + Number(m[2]);
  if (total < 0 || total > 1440 || Number(m[2]) > 59) throw new Error(`Hora fuera de rango: "${hhmm}"`);
  return total;
}

/**
 * Convierte una fecha/hora local ("2026-10-14T07:10") de la zona dada a un Date (UTC).
 * Solo se usa en el simulador de línea de comandos y en pruebas.
 */
export function desdeHoraLocal(texto, zona = 'Europe/Madrid') {
  const m = /^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})$/.exec(texto.trim());
  if (!m) throw new Error('Formato esperado: AAAA-MM-DDTHH:MM');
  const [, a, mes, d, h, mi] = m.map(Number);
  const objetivo = Date.UTC(a, mes - 1, d, h, mi);
  let t = objetivo;
  for (let i = 0; i < 3; i++) {
    const l = horaLocal(new Date(t), zona);
    const [la, lm, ld] = l.fechaISO.split('-').map(Number);
    const comoUTC = Date.UTC(la, lm - 1, ld, Math.floor(l.minutos / 60), l.minutos % 60);
    t += objetivo - comoUTC;
  }
  return new Date(t);
}
