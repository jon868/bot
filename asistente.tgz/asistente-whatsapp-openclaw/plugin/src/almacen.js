// Lectura/escritura de los archivos JSON de configuración y datos.
// Escritura atómica (archivo temporal + rename) para no corromper nada si se corta.
import fs from 'node:fs';
import path from 'node:path';

export function leerJSON(ruta, porDefecto) {
  try {
    return JSON.parse(fs.readFileSync(ruta, 'utf8'));
  } catch (e) {
    if (e.code === 'ENOENT' && porDefecto !== undefined) return structuredClone(porDefecto);
    throw new Error(`No se pudo leer ${ruta}: ${e.message}`);
  }
}

export function escribirJSON(ruta, datos) {
  fs.mkdirSync(path.dirname(ruta), { recursive: true });
  const tmp = `${ruta}.${process.pid}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(datos, null, 2) + '\n', 'utf8');
  fs.renameSync(tmp, ruta);
}

export function anotarLinea(ruta, objeto) {
  fs.mkdirSync(path.dirname(ruta), { recursive: true });
  fs.appendFileSync(ruta, JSON.stringify(objeto) + '\n', 'utf8');
}
