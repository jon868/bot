// Plan de pruebas automático:  npm test   (o: node --test test/)
import { test, describe, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { crearAsistente } from '../src/asistente.js';
import { horaLocal, desdeHoraLocal } from '../src/tiempo.js';
import { normalizarId } from '../src/identidad.js';

const PLANTILLA = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', '..', 'plantilla-datos');
const JON = '+34600000001';
const FAMILIA = '+34600000002';
const TRABAJO = '+34600000003';
const DESCONOCIDO = '+34600000004';

let dir, asistente, n = 0;
const msg = (de, texto = 'hola', extra = {}) => ({ id: `m${++n}`, remitente: de, texto, esGrupo: false, esPropio: false, ...extra });
const enMadrid = (s) => desdeHoraLocal(s, 'Europe/Madrid');
const comando = (texto, cuando = '2026-10-14T10:00') => asistente.procesar(msg(JON, texto, { esPropio: true }), enMadrid(cuando));

function preparar() {
  dir = fs.mkdtempSync(path.join(os.tmpdir(), 'asistente-'));
  fs.cpSync(PLANTILLA, dir, { recursive: true });
  const ruta = path.join(dir, 'config', 'reglas.json');
  const reglas = JSON.parse(fs.readFileSync(ruta, 'utf8'));
  reglas.propietario.numeros = [JON];
  reglas.propietario.email = 'jon@ejemplo.com';
  reglas.propietario.telefono = '600 00 00 01';
  reglas.antispam.minutos_entre_respuestas = 0; // en las pruebas de horario, sin antispam
  fs.writeFileSync(ruta, JSON.stringify(reglas));
  asistente = crearAsistente({ dataDir: dir, aleatorio: () => 0 });
  comando('estado encendido');
  comando(`grupo añadir ${FAMILIA} familia`);
  comando(`grupo añadir ${TRABAJO} trabajo`);
}

const decide = (de, cuando) => asistente.procesar(msg(de), enMadrid(cuando));

describe('Zona horaria Europe/Madrid', () => {
  test('verano (CEST, UTC+2): 05:10Z del miércoles 14/10/2026 son las 07:10 en Madrid', () => {
    const l = horaLocal(new Date('2026-10-14T05:10:00Z'));
    assert.equal(l.hora, '07:10'); assert.equal(l.dia, 'mie');
  });
  test('invierno (CET, UTC+1): 06:10Z del lunes 26/10/2026 son las 07:10 en Madrid', () => {
    const l = horaLocal(new Date('2026-10-26T06:10:00Z'));
    assert.equal(l.hora, '07:10'); assert.equal(l.dia, 'lun');
  });
  test('cambio de hora de marzo: lunes 30/03/2026 05:10Z = 07:10 Madrid', () => {
    assert.equal(horaLocal(new Date('2026-03-30T05:10:00Z')).hora, '07:10');
  });
});

describe('Plan de pruebas pedido', () => {
  beforeEach(preparar);

  test('1. Laborable 07:10 -> Bicicleta (ida) para los tres grupos', () => {
    for (const de of [FAMILIA, TRABAJO, DESCONOCIDO]) {
      const r = decide(de, '2026-10-14T07:10');
      assert.equal(r.accion, 'responder'); assert.equal(r.modo, 'bicicleta');
      assert.match(r.texto, /camino del trabajo|yendo al trabajo|de camino al trabajo/);
    }
  });

  test('2. Laborable 15:10 -> Bicicleta (vuelta) para los tres grupos', () => {
    for (const de of [FAMILIA, TRABAJO, DESCONOCIDO]) {
      const r = decide(de, '2026-10-14T15:10');
      assert.equal(r.modo, 'bicicleta'); assert.match(r.texto, /volviendo|vuelta/);
    }
  });

  test('3. Laborable 16:00 -> Trabajo: Fuera de horario; Familia y Resto: nada', () => {
    const t = decide(TRABAJO, '2026-10-14T16:00');
    assert.equal(t.modo, 'fuera_horario');
    assert.match(t.texto, /jon@ejemplo\.com/); assert.match(t.texto, /600 00 00 01/);
    assert.equal(decide(FAMILIA, '2026-10-14T16:00').accion, 'ignorar');
    assert.equal(decide(DESCONOCIDO, '2026-10-14T16:00').accion, 'ignorar');
  });

  test('4. Sábado 17:00 -> Siesta para todos (también Trabajo)', () => {
    for (const de of [FAMILIA, TRABAJO, DESCONOCIDO]) assert.equal(decide(de, '2026-10-17T17:00').modo, 'siesta');
  });

  test('5. Sábado 19:00 -> Trabajo: Fuera de horario; resto: nada', () => {
    assert.equal(decide(TRABAJO, '2026-10-17T19:00').modo, 'fuera_horario');
    assert.equal(decide(FAMILIA, '2026-10-17T19:00').accion, 'ignorar');
  });

  test('6. Domingo 15:00 -> Trabajo: Fuera de horario; resto: nada', () => {
    assert.equal(decide(TRABAJO, '2026-10-18T15:00').modo, 'fuera_horario');
    assert.equal(decide(FAMILIA, '2026-10-18T15:00').accion, 'ignorar');
    assert.equal(decide(DESCONOCIDO, '2026-10-18T15:00').accion, 'ignorar');
  });

  test('7. Charanga activa -> gana a todo, a cualquier hora y grupo', () => {
    comando('modo charanga activar');
    for (const cuando of ['2026-10-14T07:10', '2026-10-14T11:00', '2026-10-17T17:00', '2026-10-18T03:00']) {
      for (const de of [FAMILIA, TRABAJO, DESCONOCIDO]) {
        const r = decide(de, cuando);
        assert.equal(r.modo, 'charanga'); assert.match(r.texto, /txaranga/);
      }
    }
    comando('modo charanga desactivar');
    assert.equal(decide(FAMILIA, '2026-10-14T11:00').accion, 'ignorar');
  });
});

describe('Bordes y reglas generales', () => {
  beforeEach(preparar);

  test('Bordes de franja: 07:00 entra, 07:30 no; 15:30 ya es Fuera de horario para Trabajo', () => {
    assert.equal(decide(FAMILIA, '2026-10-14T07:00').modo, 'bicicleta');
    assert.equal(decide(FAMILIA, '2026-10-14T07:30').accion, 'ignorar');
    assert.equal(decide(TRABAJO, '2026-10-14T15:29').modo, 'bicicleta');
    assert.equal(decide(TRABAJO, '2026-10-14T15:30').modo, 'fuera_horario');
    assert.equal(decide(FAMILIA, '2026-10-14T15:30').accion, 'ignorar');
  });

  test('Siesta no se activa en laborable; 18:30 del sábado ya no es siesta', () => {
    assert.equal(decide(FAMILIA, '2026-10-14T17:00').accion, 'ignorar');
    assert.equal(decide(FAMILIA, '2026-10-17T18:30').accion, 'ignorar');
    assert.equal(decide(TRABAJO, '2026-10-17T18:30').modo, 'fuera_horario');
  });

  test('Bicicleta no aplica en fin de semana; Trabajo en mañana laborable no recibe nada', () => {
    assert.equal(decide(FAMILIA, '2026-10-17T07:10').accion, 'ignorar');
    assert.equal(decide(TRABAJO, '2026-10-14T10:00').accion, 'ignorar');
  });

  test('Cambio de horario real: lunes 26/10/2026 a las 07:10 de Madrid (06:10Z) -> Bicicleta; 05:10Z (06:10 Madrid) -> nada', () => {
    assert.equal(asistente.procesar(msg(FAMILIA), new Date('2026-10-26T06:10:00Z')).modo, 'bicicleta');
    assert.equal(asistente.procesar(msg(FAMILIA), new Date('2026-10-26T05:10:00Z')).accion, 'ignorar');
  });

  test('APAGADO -> no responde a nadie, ni con Charanga', () => {
    comando('modo charanga activar');
    comando('estado apagado');
    assert.equal(decide(FAMILIA, '2026-10-14T07:10').accion, 'ignorar');
    assert.equal(decide(TRABAJO, '2026-10-14T16:00').accion, 'ignorar');
  });

  test('Mismo mensaje dos veces -> solo una respuesta', () => {
    const m = msg(FAMILIA);
    assert.equal(asistente.procesar(m, enMadrid('2026-10-14T07:10')).accion, 'responder');
    const r = asistente.procesar(m, enMadrid('2026-10-14T07:10'));
    assert.equal(r.accion, 'ignorar'); assert.equal(r.motivo, 'duplicado');
  });

  test('Antispam: con 30 min, el segundo mensaje del mismo contacto en el mismo modo no se contesta', () => {
    const ruta = path.join(dir, 'config', 'reglas.json');
    const reglas = JSON.parse(fs.readFileSync(ruta, 'utf8'));
    reglas.antispam.minutos_entre_respuestas = 30;
    fs.writeFileSync(ruta, JSON.stringify(reglas));
    assert.equal(decide(FAMILIA, '2026-10-14T07:01').accion, 'responder');
    assert.equal(decide(FAMILIA, '2026-10-14T07:05').motivo, 'ya_respondido_hace_poco');
    assert.equal(decide(FAMILIA, '2026-10-14T15:05').accion, 'responder');
  });

  test('Chats de grupo, difusiones y remitentes raros se ignoran', () => {
    assert.equal(asistente.procesar(msg(FAMILIA, 'hola', { esGrupo: true }), enMadrid('2026-10-14T07:10')).accion, 'ignorar');
    assert.equal(asistente.procesar(msg('status@broadcast'), enMadrid('2026-10-14T07:10')).accion, 'ignorar');
    assert.equal(asistente.procesar(msg(undefined), enMadrid('2026-10-14T07:10')).accion, 'ignorar');
  });

  test('Desconocido queda registrado como "resto" sin clasificar', () => {
    decide(DESCONOCIDO, '2026-10-14T10:00');
    const c = JSON.parse(fs.readFileSync(path.join(dir, 'datos', 'contactos.json'), 'utf8')).contactos[DESCONOCIDO];
    assert.equal(c.grupo, 'resto'); assert.equal(c.origen, 'automatico'); assert.ok(c.actualizado);
  });

  test('Festivo entre semana: sin Bicicleta y Trabajo en Fuera de horario todo el día', () => {
    const ruta = path.join(dir, 'config', 'reglas.json');
    const reglas = JSON.parse(fs.readFileSync(ruta, 'utf8'));
    reglas.festivos = ['2026-10-12'];
    fs.writeFileSync(ruta, JSON.stringify(reglas));
    assert.equal(decide(FAMILIA, '2026-10-12T07:10').accion, 'ignorar');
    assert.equal(decide(TRABAJO, '2026-10-12T10:00').modo, 'fuera_horario');
  });

  test('Configuración con <<SUSTITUIR>> -> silencio total', () => {
    fs.cpSync(path.join(PLANTILLA, 'config', 'reglas.json'), path.join(dir, 'config', 'reglas.json'));
    const r = decide(FAMILIA, '2026-10-14T07:10');
    assert.equal(r.motivo, 'configuracion_incompleta');
  });

  test('Registro sin contenido de mensajes', () => {
    asistente.procesar(msg(FAMILIA, 'mi PIN secreto es 1234'), enMadrid('2026-10-14T07:10'));
    const log = fs.readFileSync(path.join(dir, 'registros', 'registro.jsonl'), 'utf8');
    assert.doesNotMatch(log, /PIN secreto/);
  });
});

describe('Comandos y permisos', () => {
  beforeEach(preparar);

  test('Un no autorizado no puede ejecutar comandos ni ve la configuración', () => {
    const r = asistente.procesar(msg(FAMILIA, 'estado apagado'), enMadrid('2026-10-14T10:00'));
    assert.equal(r.accion, 'ignorar');                         // a las 10:00 familia no recibe nada
    const r2 = asistente.procesar(msg(DESCONOCIDO, 'grupo listar'), enMadrid('2026-10-14T07:10'));
    assert.equal(r2.modo, 'bicicleta');                       // recibe la respuesta normal, no la lista
    assert.doesNotMatch(r2.texto, /Familia \(/);
    assert.match(comando('estado actual').texto, /Estado: ENCENDIDO/); // sigue encendido
  });

  test('estado actual / modo actual', () => {
    assert.match(comando('estado actual').texto, /Estado: ENCENDIDO/);
    const m = comando('modo actual', '2026-10-14T16:00').texto;
    assert.match(m, /Trabajo: Fuera de horario laboral/); assert.match(m, /Familia: sin respuesta/);
  });

  test('grupo añadir / cambiar / listar, con número y con nombre', () => {
    asistente.procesar(msg('+34611222333', 'hola', { nombre: 'Ama' }), enMadrid('2026-10-14T10:00'));
    assert.match(comando('grupo añadir Ama familia').texto, /Ama.*Familia/);
    assert.match(comando('grupo añadir Ama trabajo').texto, /grupo cambiar/);
    assert.match(comando('grupo cambiar Ama trabajo').texto, /pasa de Familia a Trabajo/);
    assert.match(comando('grupo cambiar 699 88 77 66 familia').texto, /No tengo registrado/);
    assert.match(comando('grupo anadir 699 88 77 66 familia').texto, /\+34699887766/);
    assert.match(comando('grupo añadir Pepe jefes').texto, /no válido/);
    const lista = comando('grupo listar').texto;
    assert.match(lista, /Familia \(2\)/); assert.match(lista, /Trabajo \(2\)/);
  });

  test('El propietario nunca recibe respuestas automáticas; sus mensajes normales pasan al LLM', () => {
    const r = asistente.procesar(msg(JON, '¿qué tal el día?'), enMadrid('2026-10-14T07:10'));
    assert.equal(r.accion, 'pasar_al_llm');
  });

  test('Comando mal escrito -> ayuda', () => {
    assert.match(comando('modo bicicleta activar').texto, /automático por horario/);
    assert.match(comando('estado raro').texto, /Comandos disponibles/);
  });
});

describe('Normalización de identificadores', () => {
  test('formatos de WhatsApp', () => {
    assert.equal(normalizarId('34600111222@s.whatsapp.net').id, '+34600111222');
    assert.equal(normalizarId('34600111222:7@s.whatsapp.net').id, '+34600111222');
    assert.equal(normalizarId('600 11 12 22').id, '+34600111222');
    assert.equal(normalizarId('0034600111222').id, '+34600111222');
    assert.equal(normalizarId('123456@g.us').tipo, 'no_humano');
    assert.equal(normalizarId('9876543210@lid').tipo, 'lid');
    assert.equal(normalizarId('Ama'), null);
  });
});
